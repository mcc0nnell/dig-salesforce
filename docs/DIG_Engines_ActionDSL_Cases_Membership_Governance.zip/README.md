# DIG Engines (Action DSL) — Cases + Membership + Governance

**Built for org alias:** `deafingov`  
**Date:** 2026-01-27

This zip contains a **Flow-minimal, Apex-first** automation architecture for:
- **DIG Ops Cases** (routing + hygiene)
- **Membership** (state machine + Contact summary + renewal notices)
- **Governance** (motions + votes + quorum/majority + scheduled close)

A shared **Action DSL + Planner/Executor** pattern powers all three.

## Deploy

```bash
sf org login web --alias deafingov
sf project deploy start --target-org deafingov --manifest manifest/dig-engines.xml
sf apex run test --target-org deafingov --test-level RunLocalTests --result-format human
```

## Notes / assumptions

- **Case trigger** is included (always safe; Case exists).
- **Membership/Governance triggers** assume your org has `Membership__c`, `Motion__c`, `Vote__c`.
  - If you don’t yet have those objects, deploy objects first (or temporarily delete the triggers).

- Custom Metadata Types included:
  - `DIG_CaseRoutingRule__mdt`
  - `DIG_MembershipLevel__mdt`, `DIG_MembershipNoticeWindow__mdt`
  - `DIG_GovPolicy__mdt`, `DIG_GovMajorityRule__mdt`, `DIG_GovNoticeWindow__mdt`

- Audit log object included:
  - `DIG_Emission__c` (append-only emissions)

## Architecture

- **Planner** computes “what should happen” into a `Dig_Plan`
- **Executor** applies DML and emits logs (idempotency keys supported)
- **Rules** are read from Custom Metadata, cached per-transaction

If you want to extend: add new planners (e.g., Sponsorships), reuse the same executor.
