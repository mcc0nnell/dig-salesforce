# DIG Comms MVP (Apex + LWC) — Zip Drop

This zip contains a minimal comms slice:
- Custom objects: `Comms_Preference__c`, `Comms_Message__c`
- Apex:
  - `CommsService` (defaults, list recent, queue send + log)
  - `CommsSendQueueable` (actually sends email + updates status)
  - `CommsInvocable` (optional Flow hook)
- LWC: `commsPanel` (Record Page component for Case + Contact)

## Deploy (SFDX)
From the repo root:
```bash
sf project deploy start --target-org deafingov --source-dir dig-src/main/default
```

## After deploy (1 minute)
1) Assign permission set **DIG Comms Admin** to yourself.
2) Add the **commsPanel** component to your **Case** and/or **Contact** Lightning Record Pages.
3) (Optional) Configure an Org-Wide Email Address and set it in `CommsSendQueueable`:
   - `sem.setOrgWideEmailAddressId('...')`

## Notes
- Consent gate: If a `Comms_Preference__c` record exists for the Contact, it enforces `Do_Not_Contact__c` and `Email_Allowed__c`.
  If no preference record exists, MVP allows sending.
- The message log is append-only by convention (you can add validation later).
