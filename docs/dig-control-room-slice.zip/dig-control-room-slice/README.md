# DIG Control Room Slice

This slice is a **deployable home** for the DIG Control Room dashboard + its reports.

## Important
Reports/dashboards are easiest to build in the Salesforce UI first.
Then retrieve them into this folder to replace the placeholders.

## Build -> Retrieve -> Commit workflow

1) Build reports + dashboard in UI (folder: DIG Control Room)
2) Retrieve:
```bash
sf project retrieve start -o deafingov -m Dashboard:DIG_Control_Room/DIG_Control_Room
sf project retrieve start -o deafingov -m Report:DIG_Control_Room/ControlRoom_Open_Cases_By_Status
# ...repeat for others
```
3) Commit retrieved metadata.

## Deploy
```bash
sf project deploy validate -o deafingov --manifest manifest/dig-control-room.xml
sf project deploy start    -o deafingov --manifest manifest/dig-control-room.xml
```
