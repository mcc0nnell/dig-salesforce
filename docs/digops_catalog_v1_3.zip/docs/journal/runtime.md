# DIG Emissions Journal Runtime

## Contract
The journal is the realtime append-only record for DIG operations.

Event envelope (minimum):
- eventId (ULID)
- spine
- streamKey
- stream = "{spine}/{streamKey}"
- seq (monotonic per stream)
- ts
- type
- actor
- source (hud|salesforce|agent)
- payload (small JSON)

## Read APIs
- Snapshot: GET /v1/streams/{spine}/{key}/snapshot
- Tail: GET /v1/streams/{spine}/{key}/tail?since=SEQ
- Stream: GET /v1/streams/{spine}/{key}/tail/stream?since=SEQ (SSE)

## Write APIs
- Emit: POST /v1/streams/{spine}/{key}/emit (facts/receipts)
- Command: POST /v1/streams/{spine}/{key}/commands/{name}
  - requires Idempotency-Key
  - emits command.requested + command.applied/rejected

## Governance HUD minimal event types
- gov.meeting.started
- gov.agenda.advanced
- gov.motion.created
- gov.vote.opened
- gov.vote.closed
- gov.comms.draft.created
- gov.comms.sent
- agent.minutes.draft.ready
