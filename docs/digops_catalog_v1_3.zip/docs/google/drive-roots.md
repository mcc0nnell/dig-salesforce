# Filesystem — Drive Roots (Shared Drives)

## Goal
Turnover-proof filesystem per spine, aligned with ten-series.

## Folder roots
- DIG Ops / 10 Membership
- DIG Ops / 20 Comms
- DIG Ops / 30 Service Ops
- DIG Ops / 40 Summit Events
- DIG Ops / 50 Governance
- DIG Ops / 70 Fundraising
- DIG Ops / 80 Knowledge
- DIG Ops / Evidence Journal
- DIG Ops / Runbooks

## Governance meetings template
DIG Ops / 50 Governance / Meetings / YYYY / Meeting-YYYY-MM-DD/
- Agenda (Doc)
- Packet (folder)
- Minutes (Doc)
- Outcomes (Doc/Sheet)
- Receipts (links/exports)

## Permissions
Assign by groups; avoid personal Drives.
