# Portal — Google Sites (ops.deafingov.org)

## Goal
Create an internal-only DIG Ops portal with ten-series navigation. The portal is the shell; engines and journals stay external.

## Sitemap
Top nav:
- Home
- 10 Membership
- 20 Comms Ops
- 30 Service Ops
- 40 Summit Events
- 50 Governance
- 70 Fundraising
- 80 Knowledge
- Evidence Journal
- Runbooks

## Publishing
Publish as internal-only (Workspace users), optionally restricted to dig-ops@deafingov.org.

## Page modules (Governance)
- Next meeting (Calendar embed)
- Packet folder link (Drive)
- HUD embed (iframe to hud.deafingov.org)
- Open motions (Sheet)
- Minutes latest + archive folder
