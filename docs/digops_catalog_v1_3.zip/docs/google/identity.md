# Identity — Google Workspace (Internal-only)

## Purpose
Use Google Workspace as the internal identity layer for DIG Ops. All access is granted through Google Groups to survive turnover.

## Required groups
Org roles:
- dig-admins@deafingov.org
- dig-ops@deafingov.org

Governance roles:
- dig-governance-operators@deafingov.org
- dig-governance-approvers@deafingov.org
- dig-governance-viewers@deafingov.org

Spine mailboxes (Google Groups / collaborative inboxes):
- membership@deafingov.org
- governance@deafingov.org
- serviceops@deafingov.org
- events@deafingov.org
- fundraising@deafingov.org
- comms@deafingov.org

## Rules
- No one-off sharing; groups only.
- Approvers are a strict subset of operators.
- Offboarding = remove from groups; artifacts remain in Shared Drives.

## Future
Public site can be added later on www.deafingov.org without changing ops identity.
