# DIG Ops slice refactor (Mermaid)

This file contains the Mermaid diagram that matches the refactored slice taxonomy:
- Summit framework slices (10/20/30/40)
- DIG Ops OS slices (layers 0–3)
- Domain families (Membership, Fundraising, Governance, Summit wrapper)
- Comms (NEXT)
- Exec rollup
- Geary Muni bundles

```mermaid
flowchart TB

%% =========================
%% Summit framework slices
%% =========================
subgraph SUMMIT["Summit framework slices"]
  S10["summit-10-data-model"]
  S20["summit-20-automation"]
  S30["summit-30-ui"]
  S40["summit-40-reporting"]
  S10 --> S20 --> S30 --> S40
  SALL["bundle: summit-all"]
  SALL --- S10
  SALL --- S20
  SALL --- S30
  SALL --- S40
end

%% =========================
%% DIG Ops OS slices (lineup)
%% =========================
subgraph OS["DIG Ops OS slices (lineup)"]
  subgraph L0["Layer 0: Base + hygiene"]
    D00["digops-00-foundation"]
    D05["digops-05-security"]
    D12["digops-12-data-quality"]
    D00 --> D05
    D00 --> D12
  end

  subgraph L1["Layer 1: Evidence + activity emissions"]
    D10["digops-10-data-model"]
    D20["digops-20-emissions-engine"]
    D22["digops-22-activity-emissions"]
    D24["digops-24-ops-index (optional)"]
    D10 --> D20 --> D22 --> D24
  end

  subgraph L2["Layer 2: Core services + enforcement"]
    D30["digops-30-core-services"]
    D32["digops-32-policy-enforcement"]
    D30 --> D32
  end

  subgraph L3["Layer 3: Operator console UI"]
    D40["digops-40-ui-home (Ops Inbox + Emissions Tail)"]
    D41["digops-41-ui-inbox"]
    D40 --> D41
  end
end

%% Base dependencies into evidence/core
D00 --> D10
D05 --> D10
D12 --> D10
D20 --> D30
D24 --> D40
D20 --> D40
D30 --> D40

%% =========================
%% Domain families
%% =========================
subgraph DOMAINS["Domain families"]
  subgraph MEM["Membership"]
    M50["digops-50-membership-core"]
    M51["digops-51-membership-ui"]
    M52["digops-52-membership-payments (optional)"]
    M53["digops-53-membership-reporting"]
    M50 --> M51
    M50 --> M52
    M50 --> M53
  end

  subgraph FUND["Fundraising"]
    F60["digops-60-fundraising-core"]
    F61["digops-61-fundraising-ui"]
    F62["digops-62-fundraising-comms (hooks into Comms)"]
    F63["digops-63-fundraising-reporting"]
    F60 --> F61
    F60 --> F62
    F60 --> F63
  end

  subgraph GOV["Governance"]
    G70["digops-70-governance-core"]
    G71["digops-71-governance-ui"]
    G72["digops-72-governance-policy"]
    G73["digops-73-governance-reporting"]
    G70 --> G71
    G70 --> G72
    G70 --> G73
  end

  subgraph SUMEXT["Summit (wrap only)"]
    X80["digops-80-summit-ext (wrap Summit UX + emissions hooks)"]
  end
end

%% Domain baseline deps (shared)
D10 --> M50
D20 --> M50
D30 --> M50
D32 --> M50

D10 --> F60
D20 --> F60
D30 --> F60
D32 --> F60

D10 --> G70
D20 --> G70
D30 --> G70
D32 --> G70

%% Summit wrapper deps
SALL --> X80
D20 --> X80
D22 --> X80
D30 --> X80

%% =========================
%% Comms (NEXT)
%% =========================
subgraph COMMS["Comms (NEXT)"]
  C90["digops-90-comms-core (DigComms__c + DigCommsDispatch__e + dispatcher + emissions)"]
  C91["digops-91-comms-ui (queue + retry + quick send)"]
  C92["digops-92-comms-reporting"]
  C90 --> C91
  C90 --> C92
end

%% Comms deps
D10 --> C90
D20 --> C90
D30 --> C90
D32 --> C90

%% Fundraising comms hook
C90 --> F62

%% =========================
%% Exec rollup
%% =========================
subgraph EXEC["Exec rollup"]
  E99["digops-99-reporting-exec (unified dashboards)"]
end

M53 --> E99
F63 --> E99
G73 --> E99
C92 --> E99
D40 --> E99

%% =========================
%% Bundles (clickables)
%% =========================
subgraph BUNDLES["Bundles you'll click in Geary Muni"]
  BCORE["digops-core = 00,05,12,10,20,22,(24),30,32"]
  BUI["digops-ui = 40,41"]
  BMEM["digops-membership = 50-53"]
  BFUND["digops-fundraising = 60-63"]
  BGOV["digops-governance = 70-73"]
  BSUM["digops-summit = 80 (+ summit-all optional)"]
  BCOMMS["digops-comms = 90-92"]
  BALL["digops-all = everything above in order"]
end
```
