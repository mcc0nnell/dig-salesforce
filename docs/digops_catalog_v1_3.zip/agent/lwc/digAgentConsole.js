// digAgentConsole.js (skeleton)
import { LightningElement } from 'lwc';
export default class DigAgentConsole extends LightningElement {}
