// digAgentDraftQueue.js (skeleton)
import { LightningElement } from 'lwc';
export default class DigAgentDraftQueue extends LightningElement {}
