// digAgentAuditTail.js (skeleton)
import { LightningElement } from 'lwc';
export default class DigAgentAuditTail extends LightningElement {}
