# Agent support (v1.1)

This package adds first-class agent support as *bounded autonomy*:

## New slices
- digops-33-agent-runtime (services band): defines agent actions, spine binding, and receipts.
- digops-43-ui-agent-console (ui band): operator UI for drafts/approvals/escalations.
- digops-54-membership-agent-pack (domain band): membership-safe actions.
- digops-74-governance-agent-pack (domain band): governance-safe actions.

## Design principles
1) Agents never send cross-spine comms. Spine mailbox + template prefixes are enforced.
2) Default mode is DRAFT ONLY. Humans approve before anything is sent.
3) Every agent action emits a receipt (emissions) with inputs/outputs and policy decision.

## UI concept
Agent Console shows:
- Draft Queue (by spine)
- Approval required (who can approve)
- Escalations (hand to human)
- Audit tail (emissions stream)

## Next step
When you export/define Agentforce configs, map them to the Apex action router endpoints
and bind channels per spine mailbox.
