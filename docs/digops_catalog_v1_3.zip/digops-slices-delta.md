# Slice delta — Google Sites internal-only portal

This update adds the minimal slices required to support an internal-only DIG Ops portal on Google Sites and a realtime journal-driven HUD.

New slices:
- digops-05-identity-google-workspace
- digops-12-portal-google-sites
- digops-14-filesystem-drive-roots
- digops-21-dig-emissions-journal-runtime
- digops-44-ui-hud-embed

Notes:
- Public WordPress site is deferred (www.deafingov.org later).
- Existing governance/comms/membership slices remain unchanged.

# Slice delta — Mermaid Intake (owned + bounded)

New slice:
- digops-41-mermaid-intake

Notes:
- Mirrors the repo work where Mermaid metadata moved to `dig-src/` and is decoupled from `comms-web`.
- Key boundedness: `X-Geary-Key` appears only in the allowlisted server-side files.

