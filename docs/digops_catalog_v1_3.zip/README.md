# DIG Ops OS — Catalog + Slice Manifests (v1)

This package includes:
- A central Spine Comms Contract (`muni/contracts/spines.yml`)
- Slice band rules (`rules/band-rules.yml`)
- A JSON Schema for slice manifests (`schema/slice.schema.json`)
- Geary 4 lint/validation rules (`rules/geary-lint-slices.md`)
- Example slice manifests for core slices (`examples/*.yml`)
- The refactor Mermaid diagram (`diagram/digops-slices-refactor.md`)

## Key invariants
1. Numbered slices are semantic bands (00–99).
2. Each spine owns its own mailbox + template namespace + comms ledger.
3. Shared subsystems (Comms Core) declare `spine: null`.
4. Geary 4 enforces these invariants at validate/deploy time.

## Suggested file placement in repo
- `muni/contracts/spines.yml` -> `muni/contracts/spines.yml`
- `rules/*` -> `docs/geary4/rules/*` (or similar)
- `schema/*` -> `schema/*`
- `examples/*` -> `slices/<slice-id>/slice.yml` (use as templates)


## v1.1 additions: Agent support + Agent UI
This package also includes:
- `examples/slice-digops-33-agent-runtime.yml`
- `examples/slice-digops-43-ui-agent-console.yml`
- `examples/slice-digops-54-membership-agent-pack.yml`
- `examples/slice-digops-74-governance-agent-pack.yml`
- `agent/docs/AGENTS.md` (design + UI concept)
- `agent/apex/*.cls` and `agent/lwc/*` (skeleton templates)


## v1.2 additions: Google Sites internal-only portal slices
Added slices + docs for:
- Google Workspace identity + groups
- Google Sites portal structure
- Drive shared roots filesystem
- DIG emissions journal runtime contract (snapshot/tail/commands)
- HUD embed pattern for governance meetings

See `digops-slices-delta.md` and `docs/google/*`, `docs/journal/runtime.md`, `docs/ui/hud-embed.md`.

## v1.3 additions: Mermaid Intake slice catalog entry
Added:
- `examples/slice-digops-41-mermaid-intake.yml`
- `docs/ui/mermaid-intake.md`

