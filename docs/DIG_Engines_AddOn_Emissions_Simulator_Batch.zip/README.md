# DIG Engines Add‑On Pack — Emissions Console + Rules Simulator + Membership Recompute

**Org alias:** `deafingov`

This is a bolt-on pack meant to be deployed alongside the main ActionDSL zip.

## What you get

1) **LWC: `digEmissionsConsole`**
   - Shows latest emissions from `DIG_Emission__c`
   - Filters by Action / RuleKey / RecordId
   - Click row → opens record in a new tab

2) **LWC: `digRulesSimulator`**
   - Paste a Case Id → runs the Case routing planner in *simulate* mode
   - Shows which rule matched and what fields would change (Owner/Status)
   - Writes nothing (no DML)

3) **Batch: `DigOps_MembershipBatchRecompute`**
   - Recomputes membership summaries for **all Contacts** (or filtered scope)
   - Uses the same logic as the trigger-driven recompute

## Deploy

```bash
sf org login web --alias deafingov
sf project deploy start --target-org deafingov --manifest manifest/dig-engines-addon.xml
```

## Optional: Run batch

```bash
sf apex run --target-org deafingov --file scripts/run_membership_recompute.apex
```

## Notes

- `DIG_Emission__c` must exist (created by the main pack).
- The Rules Simulator assumes the Case routing CMDT exists (`DIG_CaseRoutingRule__mdt`).
- If your Case fields differ from `Category__c` / `Program__c`, adjust the simulator apex.
