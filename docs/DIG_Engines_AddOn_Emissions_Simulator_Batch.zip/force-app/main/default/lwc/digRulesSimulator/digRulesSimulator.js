import { LightningElement, track } from 'lwc';
import simulateCaseRouting from '@salesforce/apex/Dig_RulesSimulatorApi.simulateCaseRouting';

export default class DigRulesSimulator extends LightningElement {
    @track caseId = '';
    @track result;
    @track error;

    onCaseId(e) { this.caseId = e.target.value; }

    async simulate() {
        this.error = null;
        this.result = null;

        if (!this.caseId) {
            this.error = 'Enter a Case Id.';
            return;
        }

        try {
            const res = await simulateCaseRouting({ caseId: this.caseId });
            this.result = res;
            if (!res || !res.matchedRuleKey) {
                this.error = 'No routing rule matched (or no active rules).';
            }
        } catch (e) {
            this.error = (e && e.body && e.body.message) ? e.body.message : 'Simulation failed.';
        }
    }
}
