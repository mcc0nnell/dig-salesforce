import { LightningElement, wire, track } from 'lwc';
import latest from '@salesforce/apex/Dig_EmissionApi.latest';
import { NavigationMixin } from 'lightning/navigation';
import { refreshApex } from '@salesforce/apex';

export default class DigEmissionsConsole extends NavigationMixin(LightningElement) {
    @track filterAction = '';
    @track filterRuleKey = '';
    @track filterRecordId = '';

    columns = [
        { label: 'Created', fieldName: 'createdDate', type: 'text' },
        { label: 'Action', fieldName: 'action', type: 'text' },
        { label: 'RuleKey', fieldName: 'ruleKey', type: 'text' },
        { label: 'Object', fieldName: 'objectType', type: 'text' },
        { label: 'RecordId', fieldName: 'recordId', type: 'text' },
        { label: 'Reason', fieldName: 'reason', type: 'text', wrapText: true },
        { type: 'button', typeAttributes: { label: 'Open', name: 'open', variant: 'base' } }
    ];

    wiredResult;
    rows = [];

    @wire(latest, { limitSize: 50, action: '$filterAction', ruleKey: '$filterRuleKey', recordId: '$filterRecordId' })
    wiredEmissions(result) {
        this.wiredResult = result;
        if (result.data) this.rows = result.data;
        if (result.error) this.rows = [];
    }

    onAction(e) { this.filterAction = e.target.value; }
    onRuleKey(e) { this.filterRuleKey = e.target.value; }
    onRecordId(e) { this.filterRecordId = e.target.value; }

    refresh() {
        if (this.wiredResult) refreshApex(this.wiredResult);
    }

    handleRowAction(event) {
        const action = event.detail.action;
        const row = event.detail.row;
        if (action.name === 'open') {
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',
                attributes: {
                    recordId: row.id,
                    objectApiName: 'DIG_Emission__c',
                    actionName: 'view'
                }
            });
        }
    }
}
