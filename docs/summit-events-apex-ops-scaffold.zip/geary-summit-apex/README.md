# Summit Events Apex Ops (Geary-ready)

This scaffold provides an Apex-first automation layer for the Summit Events package:
- deterministic instance lifecycle
- registration confirm/waitlist enforcement
- scheduled reminders + risk sweeps
- configurable behavior via Custom Metadata

See: `docs/summit-events-apex-ops.md`

## Quick commands
```bash
make validate ORG=deafingov
make deploy ORG=deafingov
```
