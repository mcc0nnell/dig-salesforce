# DIG Platform Events Pack — Emissions Event Bus + Email Subscriber

**Org alias:** `deafingov`

This pack adds:

1) `DIG_Emission__e` Platform Event (event bus mirror of `DIG_Emission__c`)
2) `Dig_EventBus.publishFromRows(...)` helper
3) Example subscriber trigger + handler:
   - when `Action__c` matches a rule (CMDT), send an email notification

## Deploy

```bash
sf org login web --alias deafingov
sf project deploy start --target-org deafingov --manifest manifest/dig-platform-events.xml
```

## Wire into the main pack (one line)

In your main pack class `Dig_Emissions.persist(...)`, after inserting the `DIG_Emission__c` rows, add:

```apex
Dig_EventBus.publishFromRows(rows);
```

That mirrors your persisted audit log into the event bus.

## Configure notifications

Custom Metadata `DIG_NotificationRule__mdt` controls which emissions generate email:

- `IsActive__c` (bool)
- `MatchAction__c` (text; exact match)
- `MatchRuleKey__c` (text; optional)
- `EmailTo__c` (text; comma-separated)
- `EmailSubject__c` (text; tokens {{action}}, {{recordId}}, {{ruleKey}})
- `EmailBody__c` (long text; tokens {{action}}, {{recordId}}, {{ruleKey}}, {{reason}})

A default rule is included for `MEMBERSHIP_NOTICE_TASK`.

## Notes

- Platform Event delivery is at-least-once; we in-transaction dedupe on `IdempotencyKey__c` when present.
- Email delivery depends on org deliverability + org-wide email settings.
