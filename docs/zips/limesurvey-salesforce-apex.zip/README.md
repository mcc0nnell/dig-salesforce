# Salesforce ↔ LimeSurvey (RemoteControl 2) Apex Starter Kit

This zip contains Apex classes you can drop into a Salesforce org to integrate with **LimeSurvey RemoteControl 2 (JSON-RPC)**.
It is written to **compile in a vanilla org** (no custom objects/metadata required).

## What’s included
- `LimeSurveyRpc.cls` — generic JSON-RPC client
- `LimeSurveyService.cls` — session management + common RemoteControl 2 methods
- `LimeSurveyTokenUtil.cls` — secure token generation helpers
- `LimeSurveyEligibilityBatch.cls` — example Batch Apex to push eligible Contacts as participants/tokens
- `LimeSurveyPoller.cls` — example schedulable turnout + close export skeleton
- `LimeSurveyWebhookEndpoint.cls` — optional inbound REST endpoint skeleton for webhook plugins

## Setup
### 1) Create a Named Credential
Create a Named Credential named **`LimeSurvey_NC`** with:
- URL: `https://YOUR-LIMESURVEY-SERVER`
- (Optional) HTTP auth if your server requires it (Basic, OAuth, etc.)

The RemoteControl endpoint is assumed to be:
`/index.php/admin/remotecontrol`

So Apex will call:
`callout:LimeSurvey_NC/index.php/admin/remotecontrol`

### 2) Store LimeSurvey RemoteControl username/password
RemoteControl uses **session-based auth** via `get_session_key(username, password)`.
For compile-safety, this kit takes the credentials as constructor arguments.

**Recommended**: store credentials outside of code (e.g., Protected Custom Metadata, Protected Custom Setting, External Credential)
and pass them in from a small org-specific wrapper.

### 3) Verify RemoteControl is enabled and the integration user has permissions
RemoteControl permissions follow the same model as the LimeSurvey admin user.

## Quick start (Anonymous Apex)
```apex
String nc = 'LimeSurvey_NC';
String lsUser = 'YOUR_LS_USER';
String lsPass = 'YOUR_LS_PASS';
Integer surveyId = 123456;

LimeSurveyService svc = new LimeSurveyService(nc, lsUser, lsPass);
String sessionKey = svc.getSessionKey();

List<LimeSurveyService.Participant> people = new List<LimeSurveyService.Participant>();
people.add(new LimeSurveyService.Participant('voter@example.com','Ada','Lovelace'));
people[0].token = LimeSurveyTokenUtil.randomTokenHex(32);
people[0].usesLeft = 1;

Object res = svc.addParticipants(sessionKey, surveyId, people, true);
System.debug(res);

svc.releaseSessionKey(sessionKey);
```

## Notes
- **Single-vote enforcement**: set `usesLeft = 1` and use a closed-access survey.
- **Secret ballots**: do not store vote content linked to Contact in Salesforce; track participation separately.
- **Webhooks**: LimeSurvey core doesn't ship first-party webhooks; plugins/forks exist. Keep a polling fallback.

---

If you want, tell me your Salesforce object names (Ballot__c, Participation__c, etc.) and your eligibility rules,
and I’ll adapt the batch + poller to your exact schema.
